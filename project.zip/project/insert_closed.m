function [ newList ] = insert_closed( newNode, CLOSED_LIST )
%Inserts Popped Node in List
newList = [CLOSED_LIST; newNode];

end

